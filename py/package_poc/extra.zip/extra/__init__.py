# -*- coding: utf-8 -*-
"""
Created on Wed Oct  2 12:07:54 2024

@author: Anoux
"""

