""" module: alpha """
 
# The location for funA would be: extra.good.alpha.funA()

def funA():
  return "Alpha"
 
if __name__ == "__main__":
  print("Alpha prefers to be a module.")