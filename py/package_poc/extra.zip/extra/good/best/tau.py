""" module: tau """
 
# The location for funT would be: extra.good.best.tau.funT()

def funT():
  return "Tau"
 
if __name__ == "__main__":
  print("Tau prefers to be a module.")