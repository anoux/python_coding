""" module: beta """
 
# The location for funB would be: extra.good.beta.funB()

def funB():
  return "Beta"
 
if __name__ == "__main__":
  print("Beta prefers to be a module.")