""" module: iota """

# The location for funI would be: extra.iota.funI()
 
def funI():
  return "Iota"
 
if __name__ == "__main__":
  print("Iota prefers to be a module.")