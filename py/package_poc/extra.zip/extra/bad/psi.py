""" module: psi """

# The location for funP would be: extra.bad.psi.funP()
 
def funP():
  return "Psi"
 
if __name__ == "__main__":
  print("Psi prefers to be a module.")