""" module: omega """
 
# The location for funO would be: extra.bad.omega.funO()

def funO():
  return "Omega"
 
if __name__ == "__main__":
  print("Omega prefers to be a module.")